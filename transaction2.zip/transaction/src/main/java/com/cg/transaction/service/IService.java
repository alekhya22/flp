package com.cg.transaction.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.transaction.dao.NetBankingDao;
import com.cg.transaction.dao.Transactiondao;
import com.cg.transaction.entities.NetBanking;
import com.cg.transaction.entities.Transaction;
@Service
public class IService implements ServiceImpl {
	@Autowired
Transactiondao transactiondao;
	@Autowired
	NetBankingDao netBankingDao;
	@Override
	public List<Transaction> insertTransaction(Transaction transaction) {
		transactiondao.save(transaction);
		return transactiondao.findAll();
		
	}
	@Override
	public List<NetBanking> insertNetBanking(NetBanking netbanking) {
		// TODO Auto-generated method stub
		netBankingDao.save(netbanking);
		return netBankingDao.findAll();
	}

}

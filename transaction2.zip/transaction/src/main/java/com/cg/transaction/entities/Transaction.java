package com.cg.transaction.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="data")
public class Transaction {
	@Id
	private long cardNo;
	private String cardName;
    private int month;
    private int year;
    private int cvv;
    public Transaction() {
	super();
	// TODO Auto-generated constructor stub
}
public Transaction(long cardNo, String cardName, int month, int year, int cvv) {
	super();
	this.cardNo = cardNo;
	this.cardName = cardName;
	this.month = month;
	this.year = year;
	this.cvv = cvv;
}
public long getCardNo() {
	return cardNo;
}
public void setCardNo(long cardNo) {
	this.cardNo = cardNo;
}
public String getCardName() {
	return cardName;
}
public void setCardName(String cardName) {
	this.cardName = cardName;
}
public int getMonth() {
	return month;
}
public void setMonth(int month) {
	this.month = month;
}
public int getYear() {
	return year;
}
public void setYear(int year) {
	this.year = year;
}
public int getCvv() {
	return cvv;
}
public void setCvv(int cvv) {
	this.cvv = cvv;
}
}

package com.cg.transaction.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.transaction.entities.Transaction;
@Repository
public interface Transactiondao extends JpaRepository<Transaction,Long>{

}

package com.cg.transaction.dao;

import org.springframework.boot.autoconfigure.data.jpa.JpaRepositoriesAutoConfiguration;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.transaction.entities.NetBanking;
import com.cg.transaction.entities.Transaction;
@Repository
public interface NetBankingDao extends JpaRepository<NetBanking,Long>{

}

package com.cg.transaction.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class NetBanking {
	
	@Id
	private String userId;
	private String password;
	private String bankType;

	public String getBankType() {
		return bankType;
	}

	public void setBankType(String bankType) {
		this.bankType = bankType;
	}

	public NetBanking() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NetBanking(String userId, String password,String bankType) {
		super();
		this.userId = userId;
		this.password = password;
		this.bankType=bankType;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}

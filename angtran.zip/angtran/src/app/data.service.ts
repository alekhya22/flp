import { Injectable } from '@angular/core';
import { Transaction } from './Transaction';
import { HttpClient } from '@angular/common/http';
import { NetBanking } from './NetBanking';

@Injectable({
  providedIn: 'root'
})
export class DataService {
 
arr:Transaction[]=[];
netarr:NetBanking[]=[];
httpClient: HttpClient;
constructor(httpClient : HttpClient) {
  this.httpClient = httpClient;
 }
 public  add(transaction: Transaction){
  return this.httpClient.post<Transaction>("http://localhost:8034/transaction",transaction);
}
public addNet(netbanking:NetBanking){
  return this.httpClient.post<NetBanking>("http://localhost:8034/netbanking",NetBanking);
}
}

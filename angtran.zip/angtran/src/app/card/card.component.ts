import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { Transaction } from '../Transaction';

@Component({
  selector: 'card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css']
})
export class CardComponent implements OnInit {
dataservice:DataService;
transaction:Transaction;
  constructor(dataservice:DataService) { 
    this.dataservice=dataservice;
  }

  ngOnInit() {
  }
  add(details:any){
    console.log(details);
   this.transaction=details;
    // this.transaction.cardName=details.cardName;
    // this.transaction.cardNo=details.cardNo;
    // this.transaction.month=details.month;
    // this.transaction.year=details.year;
    // this.transaction.cvv=details.cvv;
    this.dataservice.add(this.transaction).subscribe(data =>{
      alert("Transaction is succesfull");
    })
  }

}

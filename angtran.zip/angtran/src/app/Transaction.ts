export class Transaction {
    cardNo: Number;
    cardName: String;
    month: Number;
    year: Number;
    cvv: Number;
    constructor(cardNo: Number, cardName: String, month: Number, year: Number, cvv: Number) {
        this.cardNo = cardNo;
        this.cardName = cardName;
        this.month = month;
        this.year = year;
        this.cvv = cvv;
    }
}
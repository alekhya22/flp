import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { NetBanking } from '../NetBanking';

@Component({
  selector: 'netbanking',
  templateUrl: './netbanking.component.html',
  styleUrls: ['./netbanking.component.css']
})
export class NetbankingComponent implements OnInit {
  dataservice:DataService;
  netbanking:NetBanking;
  constructor(dataservice:DataService) { 
    this.dataservice=dataservice;
  }
  ngOnInit() {
  }
  addNet(data:any){
    console.log(data);
    this.netbanking=data;
    this.dataservice.addNet(this.netbanking).subscribe(data =>{
      alert("Transaction is succesfull");
  })
}
}

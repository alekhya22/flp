export class NetBanking{
    userId:String;
    password:String;
    constructor(    userId:String,  password:String){
        this.userId=userId;
        this.password=password;
    }
}
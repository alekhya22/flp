import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CardComponent } from './card/card.component';
import { CodComponent } from './cod/cod.component';
import { NetbankingComponent } from './netbanking/netbanking.component';



const routes: Routes = [{
  path:'card',component:CardComponent
},
{
  path:'cod',component:CodComponent
},
{
  path:'netbanking',component:NetbankingComponent
},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

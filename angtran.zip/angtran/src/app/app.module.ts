import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CardComponent } from './card/card.component';
import { NetbankingComponent } from './netbanking/netbanking.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { CodComponent } from './cod/cod.component';
import { DataService } from './data.service';


@NgModule({
  declarations: [
    AppComponent,
    CardComponent,
    NetbankingComponent,
   
    CodComponent,
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [HttpClient,DataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
